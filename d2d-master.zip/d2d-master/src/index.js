function foo(){
    alert("hello")
}